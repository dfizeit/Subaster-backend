"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const makeUser_1 = __importDefault(require("./makeUser"));
const loginUser_1 = __importDefault(require("./loginUser"));
const app_1 = require("../../functions/app");
const updatePassword_1 = __importDefault(require("./updatePassword"));
const makeAddress_1 = __importDefault(require("./makeAddress"));
const patchUser_1 = __importDefault(require("./patchUser"));
const patchAddress_1 = __importDefault(require("./patchAddress"));
const makeUsers = (0, makeUser_1.default)(app_1.encrypt.encryptString);
const loginUsers = (0, loginUser_1.default)();
const updateUserPassword = (0, updatePassword_1.default)(app_1.encrypt.encryptString);
const makeAddresses = (0, makeAddress_1.default)();
const updateUser = (0, patchUser_1.default)();
const patchUserAddress = (0, patchAddress_1.default)();
const entity = {
    makeUsers,
    patchUserAddress,
    loginUsers,
    updateUserPassword,
    makeAddresses,
    updateUser,
};
exports.default = entity;
