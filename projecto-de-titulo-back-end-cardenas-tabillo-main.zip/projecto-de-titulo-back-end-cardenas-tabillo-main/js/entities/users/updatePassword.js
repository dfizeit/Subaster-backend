"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const updatePassword = (encrypt) => {
    return function update(info) {
        const { id_user, current_password, new_password } = Object.values(info)[0];
        if (!current_password) {
            throw new Error('Please enter current password.');
        }
        if (!new_password) {
            throw new Error('Please enter new password.');
        }
        return Object.freeze({
            getID: () => id_user,
            getCurrentPassword: () => current_password,
            getNewPassword: () => __awaiter(this, void 0, void 0, function* () { return yield encrypt(new_password); }),
        });
    };
};
exports.default = updatePassword;
