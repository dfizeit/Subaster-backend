"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const makeUser = (encrypt) => {
    return function make(info) {
        const { email, user_name, first_name, last_name, address, files, phone, user_password, } = Object.values(info)[0];
        if (!email) {
            throw new Error('Please enter first Email.');
        }
        if (!first_name) {
            throw new Error('Please enter FirstName.');
        }
        if (!last_name) {
            throw new Error('Please enter LastName.');
        }
        if (!address.lat) {
            throw new Error('Error while parsing address.');
        }
        if (!address.lng) {
            throw new Error('Error while parsing address.');
        }
        if (!address.commune) {
            throw new Error('Error while parsing address.');
        }
        else {
            address.id_commune = address.commune;
            delete address.commune;
        }
        if (!address.region) {
            throw new Error('Error while parsing address.');
        }
        else {
            address.id_region = address.region;
            delete address.region;
        }
        if (!address.address) {
            throw new Error('Error while parsing address.');
        }
        if (!phone) {
            throw new Error('Please enter Phone.');
        }
        if (!user_password) {
            throw new Error('Please enter Password.');
        }
        return Object.freeze({
            getFirstName: () => first_name,
            getLastName: () => last_name,
            getUserName: () => user_name,
            getEmail: () => email,
            getAddress: () => address,
            getFiles: () => files,
            getPhone: () => phone,
            getPassword: () => __awaiter(this, void 0, void 0, function* () { return yield encrypt(user_password); }),
            getCreatedAt: () => new Date(),
        });
    };
};
exports.default = makeUser;
