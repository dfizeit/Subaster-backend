"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const optionsTemplate = {
    to: '',
    subject: '',
    html: '',
    textEncoding: 'base64',
    headers: [
        { key: 'X-Application-Developer', value: 'Rodrigo Cárdenas' },
        { key: 'X-Application-Version', value: 'v1.0.0.2' },
    ],
};
const entity = {
    optionsTemplate,
};
exports.default = entity;
