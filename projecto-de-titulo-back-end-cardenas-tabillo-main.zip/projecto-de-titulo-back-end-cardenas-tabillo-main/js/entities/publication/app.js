"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const makePublication_1 = __importDefault(require("./makePublication"));
const makeAddress_1 = __importDefault(require("./makeAddress"));
const makeFiles_1 = __importDefault(require("./makeFiles"));
const patchPublication_1 = __importDefault(require("./patchPublication"));
const patchAddress_1 = __importDefault(require("./patchAddress"));
const createAddress = (0, makeAddress_1.default)();
const createFiles = (0, makeFiles_1.default)();
const createPublication = (0, makePublication_1.default)(createAddress, createFiles);
const updatePublicationInfo = (0, patchPublication_1.default)();
const updatePublicationAddress = (0, patchAddress_1.default)();
const entity = {
    createPublication,
    createAddress,
    createFiles,
    updatePublicationInfo,
    updatePublicationAddress,
};
exports.default = entity;
