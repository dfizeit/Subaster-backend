"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const patchAddress = () => {
    return function update(info) {
        const { lat, lng, commune, region, address, description, id_address } = info;
        if (!lat) {
            throw new Error('Error while parsing address.');
        }
        if (!lng) {
            throw new Error('Error while parsing address.');
        }
        if (!commune) {
            throw new Error('Error while parsing address.');
        }
        if (!region) {
            throw new Error('Error while parsing address.');
        }
        if (!address) {
            throw new Error('Error while parsing address.');
        }
        if (!id_address) {
            throw new Error('Error while parsing address.');
        }
        return Object.freeze({
            getId: () => id_address,
            getLat: () => lat,
            getLng: () => lng,
            getAddress: () => address,
            getIdCommune: () => commune,
            getIdRegion: () => region,
            getDescription: () => description,
        });
    };
};
exports.default = patchAddress;
