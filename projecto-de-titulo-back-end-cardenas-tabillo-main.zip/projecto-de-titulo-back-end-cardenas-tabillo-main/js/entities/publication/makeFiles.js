"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const makeFiles = () => {
    return function update(files) {
        for (let file of files) {
            if (!file.url) {
                throw new Error('Insert url for every file');
            }
        }
        return Object.freeze({
            getFiles: () => files,
        });
    };
};
exports.default = makeFiles;
