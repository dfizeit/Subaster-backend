"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const makeSeller_1 = __importDefault(require("./makeSeller"));
const patchSeller_1 = __importDefault(require("./patchSeller"));
const createSeller = (0, makeSeller_1.default)();
const updateSeller = (0, patchSeller_1.default)();
const entity = {
    createSeller,
    updateSeller,
};
exports.default = entity;
