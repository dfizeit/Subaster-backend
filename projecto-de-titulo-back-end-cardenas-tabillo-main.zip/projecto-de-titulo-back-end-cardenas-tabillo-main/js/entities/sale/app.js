"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const makeSale_1 = __importDefault(require("./makeSale"));
const makeFile_1 = __importDefault(require("./makeFile"));
const createSale = (0, makeSale_1.default)();
const creaSaleFile = (0, makeFile_1.default)();
const entity = {
    createSale,
    creaSaleFile,
};
exports.default = entity;
