"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const makeFile = () => {
    return function update(file) {
        if (!file.url) {
            throw new Error('Insert file url');
        }
        if (!file.name) {
            throw new Error('Insert file name');
        }
        return Object.freeze({
            getFile: () => file,
        });
    };
};
exports.default = makeFile;
