"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.auth = exports.encrypt = void 0;
const hashings_1 = __importDefault(require("./hashings"));
const auth_1 = require("./auth");
const auth_2 = require("./auth");
exports.encrypt = (0, hashings_1.default)();
exports.auth = {
    authCreate: auth_1.authCreate,
    authVerify: auth_2.authVerify,
    authVerifySeller: auth_1.authVerifySeller,
    authVerifyAdmin: auth_1.authVerifyAdmin,
};
