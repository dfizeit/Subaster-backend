"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const get_communes_regions_1 = __importDefault(require("./get-communes-regions"));
const app_1 = __importDefault(require("../../use-cases/baseInfo/app"));
const get_categories_1 = __importDefault(require("./get-categories"));
const get_content_states_1 = __importDefault(require("./get-content-states"));
const get_product_states_1 = __importDefault(require("./get-product-states"));
const get_unities_1 = __importDefault(require("./get-unities"));
const get_publicationProperties_1 = __importDefault(require("./get-publicationProperties"));
const update_category_1 = __importDefault(require("./update-category"));
const update_unity_1 = __importDefault(require("./update-unity"));
const update_product_state_1 = __importDefault(require("./update-product-state"));
const create_category_1 = __importDefault(require("./create-category"));
const create_unity_1 = __importDefault(require("./create-unity"));
const create_product_state_1 = __importDefault(require("./create-product-state"));
const communesAndRegions = (0, get_communes_regions_1.default)(app_1.default.countryInfo);
const categories = (0, get_categories_1.default)(app_1.default.attributesCategories);
const contentStates = (0, get_content_states_1.default)(app_1.default.attributesContentStates);
const productStates = (0, get_product_states_1.default)(app_1.default.attributesProductStates);
const unities = (0, get_unities_1.default)(app_1.default.attributesUnities);
const publicactionAttributes = (0, get_publicationProperties_1.default)(app_1.default.allAttributes);
const patchCategory = (0, update_category_1.default)(app_1.default.patchCategory);
const patchUnity = (0, update_unity_1.default)(app_1.default.patchUnity);
const patchProductState = (0, update_product_state_1.default)(app_1.default.patchProductState);
const insertCategory = (0, create_category_1.default)(app_1.default.insertCategory);
const insertUnity = (0, create_unity_1.default)(app_1.default.insertUnity);
const insertProducState = (0, create_product_state_1.default)(app_1.default.insertProducState);
const baseInfoController = {
    communesAndRegions,
    categories,
    contentStates,
    productStates,
    unities,
    publicactionAttributes,
    insertCategory,
    insertUnity,
    insertProducState,
    patchCategory,
    patchUnity,
    patchProductState,
};
exports.default = baseInfoController;
