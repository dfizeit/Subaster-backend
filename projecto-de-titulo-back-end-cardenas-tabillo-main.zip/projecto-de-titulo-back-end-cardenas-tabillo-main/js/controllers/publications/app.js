"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const insert_publication_1 = __importDefault(require("./insert-publication"));
const app_1 = __importDefault(require("../../use-cases/publicactions/app"));
const get_publications_by_seller_1 = __importDefault(require("./get-publications-by-seller"));
const get_all_publications_by_region_1 = __importDefault(require("./get-all-publications-by-region"));
const get_publication_1 = __importDefault(require("./get-publication"));
const delete_file_1 = __importDefault(require("./delete-file"));
const add_file_1 = __importDefault(require("./add-file"));
const update_publication_1 = __importDefault(require("./update-publication"));
const update_address_1 = __importDefault(require("./update-address"));
const get_publications_stock_1 = __importDefault(require("./get-publications-stock"));
const disable_publication_1 = __importDefault(require("./disable-publication"));
const get_all_publications_1 = __importDefault(require("./get-all-publications"));
const insert_comment_1 = __importDefault(require("./insert-comment"));
const can_comment_1 = __importDefault(require("./can-comment"));
const home_metrics_1 = __importDefault(require("./home-metrics"));
const re_activate_1 = __importDefault(require("./re-activate"));
const disableByAdmin_1 = __importDefault(require("./disableByAdmin"));
const enable_publication_1 = __importDefault(require("./enable-publication"));
const enable_publication_by_admin_1 = __importDefault(require("./enable-publication-by-admin"));
const get_all_publications_for_admin_1 = __importDefault(require("./get-all-publications-for-admin"));
const postPublication = (0, insert_publication_1.default)(app_1.default.postPublicaction);
const getPublicationsBySeller = (0, get_publications_by_seller_1.default)(app_1.default.getSellerPublications);
const getPublicationsByRegion = (0, get_all_publications_by_region_1.default)(app_1.default.getRegionPublications);
const getPublication = (0, get_publication_1.default)(app_1.default.getPublication);
const deleteFile = (0, delete_file_1.default)(app_1.default.deleteFile);
const addFile = (0, add_file_1.default)(app_1.default.addFile);
const patchPublication = (0, update_publication_1.default)(app_1.default.updatePublication);
const patchPublicationAddress = (0, update_address_1.default)(app_1.default.updateAddress);
const getPublicationsStocks = (0, get_publications_stock_1.default)(app_1.default.getPublicationsStocks);
const closePublication = (0, disable_publication_1.default)(app_1.default.closePublication);
const closePublicationByAdmin = (0, disableByAdmin_1.default)(app_1.default.closePublicationByAdmmin);
const openPublication = (0, enable_publication_1.default)(app_1.default.openPublication);
const openPublicationByAdmin = (0, enable_publication_by_admin_1.default)(app_1.default.openPublicationByAdmin);
const getPublications = (0, get_all_publications_1.default)(app_1.default.getAllPublications);
const getPublicationsForAdmin = (0, get_all_publications_for_admin_1.default)(app_1.default.getAllPublicationsForAdmin);
const postComment = (0, insert_comment_1.default)(app_1.default.postComment);
const getCommentPermission = (0, can_comment_1.default)(app_1.default.getCommentPermission);
const getHomeInfo = (0, home_metrics_1.default)(app_1.default.getHomeInfo);
const repeatPublication = (0, re_activate_1.default)(app_1.default.repeatPublication);
const publicactionController = {
    addFile,
    repeatPublication,
    deleteFile,
    getHomeInfo,
    closePublication,
    closePublicationByAdmin,
    openPublication,
    openPublicationByAdmin,
    patchPublication,
    getPublications,
    getPublicationsForAdmin,
    getCommentPermission,
    patchPublicationAddress,
    postPublication,
    postComment,
    getPublication,
    getPublicationsBySeller,
    getPublicationsByRegion,
    getPublicationsStocks,
};
exports.default = publicactionController;
