"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const make_sale_1 = __importDefault(require("./make-sale"));
const app_1 = __importDefault(require("../../use-cases/sale/app"));
const get_sale_by_user_1 = __importDefault(require("./get-sale-by-user"));
const get_sale_detail_by_user_1 = __importDefault(require("./get-sale-detail-by-user"));
const get_sale_detail_by_seller_1 = __importDefault(require("./get-sale-detail-by-seller"));
const insert_sale_file_1 = __importDefault(require("./insert-sale-file"));
const remove_sale_file_1 = __importDefault(require("./remove-sale-file"));
const get_sale_by_seller_1 = __importDefault(require("./get-sale-by-seller"));
const complete_sale_1 = __importDefault(require("./complete-sale"));
const reject_sale_1 = __importDefault(require("./reject-sale"));
const insertSale = (0, make_sale_1.default)(app_1.default.insertSale);
const getUserSales = (0, get_sale_by_user_1.default)(app_1.default.getSalesByUser);
const getSellerSales = (0, get_sale_by_seller_1.default)(app_1.default.getSalesBySeller);
const getSaleDetailUser = (0, get_sale_detail_by_user_1.default)(app_1.default.getSaleDetailUser);
const getSaleDetailSeller = (0, get_sale_detail_by_seller_1.default)(app_1.default.getSaleDetailSeller);
const addUserSaleFile = (0, insert_sale_file_1.default)(app_1.default.insertUserSaleFile);
const deleteUserSaleFile = (0, remove_sale_file_1.default)(app_1.default.removeUserSaleFile);
const completeSale = (0, complete_sale_1.default)(app_1.default.acceptSale);
const rejectSaleController = (0, reject_sale_1.default)(app_1.default.cancelSale);
const saleController = {
    insertSale,
    deleteUserSaleFile,
    completeSale,
    rejectSaleController,
    addUserSaleFile,
    getSaleDetailUser,
    getSaleDetailSeller,
    getUserSales,
    getSellerSales,
};
exports.default = saleController;
