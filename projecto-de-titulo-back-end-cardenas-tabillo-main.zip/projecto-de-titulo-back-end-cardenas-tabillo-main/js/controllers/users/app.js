"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const app_1 = __importDefault(require("../../use-cases/users/app"));
const insert_user_1 = __importDefault(require("./insert-user"));
const login_user_1 = __importDefault(require("./login-user"));
const update_user_1 = __importDefault(require("./update-user"));
const delete_user_field_1 = __importDefault(require("./delete-user-field"));
const get_user_1 = __importDefault(require("./get-user"));
const password_recovery_1 = __importDefault(require("./password-recovery"));
const createUser = (0, insert_user_1.default)(app_1.default.createUser);
const loginUser = (0, login_user_1.default)(app_1.default.loginUser);
const updateUser = (0, update_user_1.default)(app_1.default.updateUser);
const updateUserPassword = (0, update_user_1.default)(app_1.default.updatePassword);
const updateUserAddress = (0, update_user_1.default)(app_1.default.updateAddress);
const updateUserFile = (0, update_user_1.default)(app_1.default.updateFile);
const deleteUserFile = (0, delete_user_field_1.default)(app_1.default.deleteFile);
const getUserByToken = (0, get_user_1.default)(app_1.default.getUserByToken);
const passworRecovery = (0, password_recovery_1.default)(app_1.default.userPasswordRecovery);
const userController = {
    createUser,
    loginUser,
    updateUser,
    updateUserPassword,
    updateUserAddress,
    updateUserFile,
    deleteUserFile,
    getUserByToken,
    passworRecovery,
};
exports.default = userController;
