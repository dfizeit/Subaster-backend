"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const queryFiles = (conn, models) => {
    return Object.freeze({
        insertFiles,
        updateFile,
    });
    function insertFiles(files, credentials) {
        return __awaiter(this, void 0, void 0, function* () {
            const transaction = yield models.sequelize.transaction();
            try {
                const File = models.user_file;
                for (let index in files) {
                    files[index].extension =
                        files[index].extension && files[index].extension.length > 0
                            ? files[index].extension
                            : null;
                    files[index] = Object.assign(Object.assign({}, files[index]), credentials);
                }
                const insertedFiles = File.bulkCreate(files);
                if (insertedFiles.Error) {
                    throw insertedFiles.Error;
                }
                yield transaction.commit();
                return { data: insertedFiles, error: null };
            }
            catch (e) {
                yield transaction.rollback();
                return { data: null, error: e };
            }
        });
    }
    function updateFile(id, file) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const File = models.user_file;
                file.extension =
                    file.extension && file.extension.length > 0 ? file.extension : null;
                const insertedFiles = File.update(file, { where: { id_file: id } });
                if (insertedFiles.Error) {
                    throw insertedFiles.Error;
                }
                return { data: insertedFiles, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function deleteFile(id) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const File = models.user_file;
                const insertedFiles = File.destroy({ where: { id_file: id } });
                if (!insertedFiles.Errors || insertedFiles.Errors) {
                    throw insertedFiles.Errors
                        ? insertedFiles.Errors
                        : new Error('Error while deleting file.');
                }
                return { data: insertedFiles, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
};
exports.default = queryFiles;
