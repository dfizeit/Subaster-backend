"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const app_1 = __importDefault(require("../fixed_address/app"));
const app_2 = __importDefault(require("../comment/app"));
const { v4: uuidv4 } = require('uuid');
const queryFixed = (conn, models) => {
    return Object.freeze({
        post,
        getPublication,
        getPublications,
        getAllPublicationsForAdmin,
        getSellerPublications,
        getRegionPublications,
        updatePublicationInfo,
        getStocks,
        reActivate,
        closePublication,
        closePublicationByAdmin,
        openPublication,
        openPublicationByAdmin,
        getHomeInfo,
    });
    function post(values) {
        return __awaiter(this, void 0, void 0, function* () {
            const transaction = yield models.sequelize.transaction();
            try {
                const Publication = models.publication;
                const states = models.content_state;
                const state = yield states.findOne({
                    where: { content_state: 'disponible' },
                    raw: true,
                });
                const { address, files } = values, rest = __rest(values, ["address", "files"]);
                const publication = yield Publication.create(Object.assign(Object.assign({}, rest), { current_stock: rest.stock, content_state: state.id_state, created_at: new Date() }), {
                    raw: true,
                });
                const PublicationAddress = models.publication_address;
                const fixedAddress = yield PublicationAddress.create(Object.assign(Object.assign({}, address), { id_commune: address.commune, id_region: address.region, id_fixed: publication.id_fixed }), {
                    raw: true,
                });
                const PublicationFile = models.publication_file;
                const [fixedFiles, created] = yield PublicationFile.bulkCreate(files.map((file) => {
                    return Object.assign(Object.assign({}, file), { id_fixed: publication.id_fixed });
                }));
                publication['files'] = fixedFiles;
                publication['address'] = fixedAddress;
                yield transaction.commit();
                return { data: publication, error: null };
            }
            catch (e) {
                yield transaction.rollback();
                return { data: null, error: e };
            }
        });
    }
    function getSellerPublications(id_seller) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Publication = models.publication;
                const PublicationAddress = models.publication_address;
                const PublicationFile = models.publication_file;
                let publications = yield Publication.findAll({
                    where: { id_seller: id_seller },
                    raw: true,
                });
                for (let publication of publications) {
                    publication.files = yield PublicationFile.findAll({
                        where: { id_fixed: publication.id_fixed },
                        raw: true,
                    });
                    publication.address = yield PublicationAddress.findOne({
                        where: { id_fixed: publication.id_fixed },
                        raw: true,
                    });
                }
                return { data: publications, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function getPublications(filters) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Publication = models.publication;
                const Files = models.publication_file;
                const Address = models.publication_address;
                const ContentState = models.content_state;
                Publication.hasMany(Files, { foreignKey: 'id_fixed' });
                Publication.hasOne(Address, { foreignKey: 'id_fixed' });
                Files.belongsTo(Publication, {
                    foreignKey: 'id_fixed',
                });
                Address.belongsTo(Publication, {
                    foreignKey: 'id_fixed',
                });
                let pubFilters = {};
                if (filters.category && filters.category.length > 0) {
                    pubFilters['category'] = filters.category;
                }
                if (filters.unity && filters.unity.length > 0) {
                    pubFilters['unity'] = filters.unity;
                }
                if (filters.product_state && filters.product_state.length > 0) {
                    pubFilters['product_state'] = filters.product_state;
                }
                if (filters.title && filters.title.length > 0) {
                    const Op = models.Sequelize.Op;
                    pubFilters['title'] = { [Op.match]: filters.title };
                }
                const state = yield ContentState.findOne({
                    where: { content_state: 'disponible' },
                    raw: true,
                    nest: true,
                });
                let publications = yield Publication.findAll({
                    where: Object.assign(Object.assign({}, pubFilters), { content_state: state.id_state }),
                    include: [{ model: Files }, { model: Address }],
                    limit: filters.limit ? filters.limit : null,
                    offset: filters.offset ? filters.offset : 0,
                });
                let count = yield Publication.count({
                    where: Object.assign(Object.assign({}, pubFilters), { content_state: state.id_state }),
                });
                return { data: { count: count, items: publications }, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function getAllPublicationsForAdmin(filters) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Publication = models.publication;
                const Files = models.publication_file;
                const Address = models.publication_address;
                Publication.hasMany(Files, { foreignKey: 'id_fixed' });
                Publication.hasOne(Address, { foreignKey: 'id_fixed' });
                Files.belongsTo(Publication, {
                    foreignKey: 'id_fixed',
                });
                Address.belongsTo(Publication, {
                    foreignKey: 'id_fixed',
                });
                let pubFilters = {};
                if (filters.category && filters.category.length > 0) {
                    pubFilters['category'] = filters.category;
                }
                if (filters.unity && filters.unity.length > 0) {
                    pubFilters['unity'] = filters.unity;
                }
                if (filters.product_state && filters.product_state.length > 0) {
                    pubFilters['product_state'] = filters.product_state;
                }
                if (filters.title && filters.title.length > 0) {
                    const Op = models.Sequelize.Op;
                    pubFilters['title'] = { [Op.match]: filters.title };
                }
                let publications = yield Publication.findAll({
                    where: Object.assign({}, pubFilters),
                    include: [{ model: Files }, { model: Address }],
                    limit: filters.limit ? filters.limit : null,
                    offset: filters.offset ? filters.offset : 0,
                });
                let count = yield Publication.count({
                    where: Object.assign({}, pubFilters),
                });
                return { data: { count: count, items: publications }, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function getStocks(ids) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Publication = models.publication;
                const Files = models.publication_file;
                const Address = models.publication_address;
                Publication.hasMany(Files, { foreignKey: 'id_fixed' });
                Publication.hasOne(Address, { foreignKey: 'id_fixed' });
                Files.belongsTo(Publication, {
                    foreignKey: 'id_fixed',
                });
                Address.belongsTo(Publication, {
                    foreignKey: 'id_fixed',
                });
                let publications = yield Publication.findAll({
                    where: { id_fixed: ids },
                    include: [{ model: Files }, { model: Address }],
                });
                return { data: publications, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function getRegionPublications(id_region) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Publication = models.publication;
                const PublicationAddress = models.publication_address;
                const PublicationFile = models.publication_file;
                let publicationsAddresses = yield PublicationAddress.findAll({
                    where: { id_region: id_region },
                    raw: true,
                    nest: true,
                });
                let publications = yield Publication.findAll({
                    where: {
                        id_fixed: publicationsAddresses.map((address) => address.id_fixed),
                    },
                    raw: true,
                    nest: true,
                });
                for (let publication of publications) {
                    publication.files = yield PublicationFile.findAll({
                        where: { id_fixed: publication.id_fixed },
                        raw: true,
                    });
                    publication.address = publicationsAddresses.filter((address) => address.id_fixed === publication.id_fixed ? address : null)[0];
                }
                return { data: publications, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function getPublication(id_fixed) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Publication = models.publication;
                const PublicationFile = models.publication_file;
                const ContentState = models.content_state;
                let publication = yield Publication.findOne({
                    where: { id_fixed: id_fixed },
                    raw: true,
                });
                publication.comments = (yield app_2.default.getComments(publication.id_fixed)).data;
                publication.files = yield PublicationFile.findAll({
                    where: { id_fixed: publication.id_fixed },
                    raw: true,
                });
                const { data: address, error: addressError } = yield app_1.default.getAddress(publication.id_fixed);
                if (addressError) {
                    throw addressError;
                }
                publication.address = address;
                publication.content_state = yield ContentState.findOne({
                    where: { id_state: publication.content_state },
                    raw: true,
                });
                return { data: publication, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function closePublication(id_fixed) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Publication = models.publication;
                const Stock = models.stock;
                const ContentStates = models.content_state;
                const state = yield ContentStates.findAll({
                    where: { content_state: ['inactiva', 'disponible'] },
                    raw: true,
                });
                const publicationDeleted = yield Publication.update({
                    content_state: state.filter((v) => v.content_state === 'inactiva' ? v : null)[0].id_state,
                }, {
                    where: { id_fixed: id_fixed },
                    raw: true,
                    returning: true,
                });
                yield Stock.update({
                    stock_state: state.filter((v) => v.content_state === 'inactiva' ? v : null)[0].id_state,
                }, {
                    where: {
                        id_fixed: id_fixed,
                        stock_state: state.filter((v) => v.content_state === 'disponible' ? v : null)[0].id_state,
                    },
                });
                return { data: publicationDeleted[1][0], error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function closePublicationByAdmin(id_fixed) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Publication = models.publication;
                const Stock = models.stock;
                const ContentStates = models.content_state;
                const state = yield ContentStates.findAll({
                    where: { content_state: ['inactiva', 'disponible'] },
                    raw: true,
                });
                const publicationDeleted = yield Publication.update({
                    content_state: state.filter((v) => v.content_state === 'inactiva' ? v : null)[0].id_state,
                    closed_by_admin: true,
                }, {
                    where: { id_fixed: id_fixed },
                    raw: true,
                    returning: true,
                });
                yield Stock.update({
                    stock_state: state.filter((v) => v.content_state === 'inactiva' ? v : null)[0].id_state,
                }, {
                    where: {
                        id_fixed: id_fixed,
                        stock_state: state.filter((v) => v.content_state === 'disponible' ? v : null)[0].id_state,
                    },
                });
                return { data: publicationDeleted[1][0], error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function openPublication(id_fixed) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Publication = models.publication;
                const Stock = models.stock;
                const ContentStates = models.content_state;
                const state = yield ContentStates.findAll({
                    where: { content_state: ['inactiva', 'disponible'] },
                    raw: true,
                });
                const publicationActivated = yield Publication.update({
                    content_state: state.filter((v) => v.content_state === 'disponible' ? v : null)[0].id_state,
                }, {
                    where: { id_fixed: id_fixed },
                    raw: true,
                    returning: true,
                });
                yield Stock.update({
                    stock_state: state.filter((v) => v.content_state === 'disponible' ? v : null)[0].id_state,
                }, {
                    where: {
                        id_fixed: id_fixed,
                        stock_state: state.filter((v) => v.content_state === 'inactiva' ? v : null)[0].id_state,
                    },
                });
                return { data: publicationActivated[1][0], error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function openPublicationByAdmin(id_fixed) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Publication = models.publication;
                const Stock = models.stock;
                const ContentStates = models.content_state;
                const state = yield ContentStates.findAll({
                    where: { content_state: ['inactiva', 'disponible'] },
                    raw: true,
                });
                const publicationActivated = yield Publication.update({
                    content_state: state.filter((v) => v.content_state === 'disponible' ? v : null)[0].id_state,
                    closed_by_admin: false,
                }, {
                    where: { id_fixed: id_fixed },
                    raw: true,
                    returning: true,
                });
                yield Stock.update({
                    stock_state: state.filter((v) => v.content_state === 'disponible' ? v : null)[0].id_state,
                }, {
                    where: {
                        id_fixed: id_fixed,
                        stock_state: state.filter((v) => v.content_state === 'inactiva' ? v : null)[0].id_state,
                    },
                });
                return { data: publicationActivated[1][0], error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function reActivate(id_fixed) {
        return __awaiter(this, void 0, void 0, function* () {
            const transaction = yield models.sequelize.transaction();
            try {
                const Publication = models.publication;
                const Stock = models.stock;
                const ContentStates = models.content_state;
                const state = yield ContentStates.findOne({
                    where: { content_state: 'disponible' },
                    raw: true,
                    nest: true,
                });
                const publication = yield Publication.findOne({
                    where: { id_fixed: id_fixed },
                    raw: true,
                    nest: true,
                });
                const publicationActivated = yield Publication.update(Object.assign(Object.assign({}, publication), { content_state: state.id_state, current_stock: publication.stock }), {
                    where: { id_fixed: id_fixed },
                    raw: true,
                    returning: true,
                });
                for (let i = 0; i < publication.stock; i++) {
                    yield Stock.create({
                        id_fixed: publication.id_fixed,
                        stock_state: state.id_state,
                    });
                }
                transaction.commit();
                return { data: publicationActivated[1][0], error: null };
            }
            catch (e) {
                transaction.rollback();
                return { data: null, error: e };
            }
        });
    }
    function updatePublicationInfo(values) {
        return __awaiter(this, void 0, void 0, function* () {
            const transaction = yield models.sequelize.transaction();
            try {
                const id_fixed = values.id_fixed;
                const Publication = models.publication;
                const publication = yield Publication.findOne({
                    where: { id_fixed: id_fixed },
                });
                if (values.current_stock !== publication.current_stock) {
                    const Stock = models.stock;
                    const ContentStates = models.content_state;
                    const stocks = yield Stock.findAll({
                        where: { id_fixed: id_fixed },
                        raw: true,
                    });
                    const state = yield ContentStates.findOne({
                        where: { content_state: 'disponible' },
                        raw: true,
                    });
                    if (values.current_stock > publication.current_stock) {
                        for (let i = 0; i < values.current_stock - publication.current_stock; i++) {
                            const newStock = yield Stock.create({
                                id_stock: uuidv4(),
                                id_fixed: id_fixed,
                                stock_state: state.id_state,
                            }, { raw: true });
                            if (!(newStock === null || newStock === void 0 ? void 0 : newStock.id_stock)) {
                                throw new Error('Error al actualizar publicación');
                            }
                        }
                    }
                    else {
                        if (publication.current_stock - values.current_stock >
                            stocks.filter((stock) => stock.stock_state === state.id_state ? stock : null).length) {
                            throw new Error('Error al actualizar publicación');
                        }
                        const avaibles = stocks.filter((stock) => stock.stock_state === state.id_state ? stock : null);
                        for (let i = 0; i < publication.current_stock - values.current_stock; i++) {
                            const deletedStock = yield Stock.destroy({
                                where: { id_stock: avaibles[i].id_stock },
                                raw: true,
                            });
                            if (!deletedStock || deletedStock === 0) {
                                throw new Error('Error al actualizar publicación');
                            }
                        }
                    }
                    const updated = yield Publication.update(values, {
                        where: { id_fixed: id_fixed },
                        raw: true,
                        returning: true,
                    });
                    if (!updated[0] || updated[0] === 0) {
                        throw new Error('Error al actualizar publicación');
                    }
                    yield transaction.commit();
                    return { data: updated[1], error: null };
                }
                else {
                    const updated = yield Publication.update(values, {
                        where: { id_fixed: id_fixed },
                        raw: true,
                        returning: true,
                    });
                    console.log(updated);
                    if (!updated[0] || updated[0] === 0) {
                        throw new Error('Error al actualizar publicación');
                    }
                    yield transaction.commit();
                    return { data: updated[1], error: null };
                }
            }
            catch (e) {
                console.log(e);
                yield transaction.rollback();
                return { data: null, error: e };
            }
        });
    }
    function getHomeInfo() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const User = models.user;
                const ContentState = models.content_state;
                const Publication = models.publication;
                const Files = models.publication_file;
                const totalWeight = yield models.sequelize.query('SELECT SUM(weight) as totalWeight FROM stock\n' +
                    'INNER JOIN content_state ON id_state = stock_state\n' +
                    'INNER JOIN fixed ON fixed.id_fixed = stock.id_fixed\n' +
                    "WHERE id_sale IS NOT NULL AND content_state.content_state = 'completado' ", { raw: true, nest: true });
                const state = yield ContentState.findOne({
                    where: { content_state: 'disponible' },
                    raw: true,
                    nest: true,
                });
                const users = yield User.count();
                const latest = yield Publication.findAll({
                    where: { content_state: state.id_state },
                    raw: true,
                    nest: true,
                    order: [['created_at', 'DESC']],
                    limit: 10,
                });
                for (let publication of latest) {
                    publication.files = yield Files.findAll({
                        where: { id_fixed: publication.id_fixed },
                        raw: true,
                        nest: true,
                    });
                }
                const moreComments = yield models.sequelize.query('SELECT id_fixed, COUNT(id_fixed) AS "comments" FROM "comment" GROUP BY id_fixed ORDER BY "comments" DESC LIMIT 10', { raw: true, nest: true });
                const moreCommentsPublications = yield Publication.findAll({
                    where: {
                        id_fixed: moreComments.map((info) => info.id_fixed),
                        content_state: state.id_state,
                    },
                    raw: true,
                    nest: true,
                });
                for (let publication of moreCommentsPublications) {
                    publication.files = yield Files.findAll({
                        where: { id_fixed: publication.id_fixed },
                        raw: true,
                        nest: true,
                    });
                }
                return {
                    data: Object.assign(Object.assign({ users }, totalWeight[0]), { moreComments: moreCommentsPublications, latest }),
                    error: null,
                };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
};
exports.default = queryFixed;
