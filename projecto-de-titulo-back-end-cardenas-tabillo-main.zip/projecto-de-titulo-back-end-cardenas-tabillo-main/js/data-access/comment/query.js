"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const uuid = require('uuid');
const queryComment = (conn, models) => {
    return Object.freeze({
        getComments,
        createComment,
        canComment,
    });
    function getComments(id_fixed) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Comment = models.comment;
                const User = models.user;
                const comments = yield Comment.findAll({
                    where: { id_fixed: id_fixed },
                    raw: true,
                });
                for (let comment of comments) {
                    comment.user = yield User.findOne({
                        attributes: ['first_name', 'last_name'],
                        where: { id_user: comment.id_user },
                    });
                }
                return { data: comments, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function createComment(values) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                console.log('dentro', values);
                const Comment = models.comment;
                const comment = yield Comment.create(Object.assign(Object.assign({}, values), { id_comment: uuid.v4() }), {
                    raw: true,
                    nest: true,
                });
                return { data: comment, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function canComment(id_user, id_fixed) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Stock = models.stock;
                const ContentState = models.content_state;
                const Sale = models.sale;
                const state = yield ContentState.findOne({
                    where: { content_state: 'completado' },
                    raw: true,
                    nest: true,
                });
                const sales = yield Sale.findAll({
                    attributes: ['id_sale'],
                    where: { sale_state: state.id_state, id_user: id_user },
                    raw: true,
                    nest: true,
                });
                const stocks = yield Stock.findAll({
                    where: {
                        id_fixed: id_fixed,
                        id_sale: sales.map((id) => id.id_sale),
                        stock_state: state.id_state,
                    },
                    raw: true,
                    nest: true,
                });
                return { data: stocks.length > 0, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
};
exports.default = queryComment;
