"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const queryAttributes = (conn, models) => {
    return Object.freeze({
        getCategories,
        getContentStates,
        getUnities,
        getProductStates,
        updateCategory,
        updateProductState,
        updateUnity,
        createCategory,
        createUnity,
        createProductState,
    });
    function getCategories() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Categorie = models.publication_category;
                const categories = yield Categorie.findAll({ raw: true });
                if ((categories === null || categories === void 0 ? void 0 : categories.length) <= 0) {
                    throw new Error('Error while getting categories.');
                }
                return { data: categories, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function getContentStates() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const ContentState = models.content_state;
                const contentStates = yield ContentState.findAll({ raw: true });
                if ((contentStates === null || contentStates === void 0 ? void 0 : contentStates.length) <= 0) {
                    throw new Error('Error while getting contentStates.');
                }
                return { data: contentStates, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function getUnities() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Unity = models.publication_unity;
                const unities = yield Unity.findAll({ raw: true });
                if ((unities === null || unities === void 0 ? void 0 : unities.length) <= 0) {
                    throw new Error('Error while getting unities.');
                }
                return { data: unities, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function getProductStates() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const PublicationProductState = models.publication_product_state;
                const publicationProductStates = yield PublicationProductState.findAll({
                    raw: true,
                });
                if ((publicationProductStates === null || publicationProductStates === void 0 ? void 0 : publicationProductStates.length) <= 0) {
                    throw new Error('Error while getting productStates.');
                }
                return { data: publicationProductStates, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function updateCategory(id_pubc, publication_category) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Category = models.publication_category;
                const category = yield Category.findOne({
                    where: { id_pubc: id_pubc },
                    raw: true,
                    nest: true,
                });
                const updatedCategory = yield Category.update(Object.assign(Object.assign({}, category), { publication_category: publication_category }), { where: { id_pubc: id_pubc }, raw: true, nest: true });
                return { data: updatedCategory, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function updateProductState(id_pubs, product_state) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const ProductState = models.publication_product_state;
                const productState = yield ProductState.findOne({
                    where: { id_pubs: id_pubs },
                    raw: true,
                    nest: true,
                });
                const updatedProductState = yield ProductState.update(Object.assign(Object.assign({}, productState), { product_state: product_state }), { where: { id_pubs: id_pubs }, raw: true, nest: true });
                return { data: updatedProductState, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function updateUnity(id_unity, publication_unity) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Unity = models.publication_unity;
                const unity = yield Unity.findOne({
                    where: { id_unity: id_unity },
                    raw: true,
                    nest: true,
                });
                console.log(id_unity, publication_unity);
                const updatedUnity = yield Unity.update(Object.assign(Object.assign({}, unity), { publication_unity: publication_unity }), { where: { id_unity: id_unity }, raw: true, nest: true });
                return { data: updatedUnity, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function createCategory(publication_category) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Category = models.publication_category;
                const newCategory = yield Category.create({
                    publication_category: publication_category,
                });
                return { data: newCategory, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function createUnity(publication_unity) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Unity = models.publication_unity;
                const newUnity = yield Unity.create({
                    publication_unity: publication_unity,
                });
                return { data: newUnity, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function createProductState(product_state) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const ProductState = models.publication_product_state;
                const newProductState = yield ProductState.create({
                    product_state: product_state,
                });
                return { data: newProductState, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
};
exports.default = queryAttributes;
