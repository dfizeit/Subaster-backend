"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const { Model } = require('sequelize');
module.exports = (sequelize, DataTypes) => {
    class PublicationCategory extends Model {
    }
    PublicationCategory.init({
        id_pubc: {
            type: DataTypes.UUID,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false,
        },
        publication_category: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
    }, {
        sequelize,
        modelName: 'publication_category',
        tableName: 'publication_category',
        timestamps: false,
    });
    return PublicationCategory;
};
