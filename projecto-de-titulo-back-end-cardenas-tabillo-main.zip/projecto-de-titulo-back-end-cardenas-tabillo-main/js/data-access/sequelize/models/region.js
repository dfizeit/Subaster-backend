"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const { Model } = require('sequelize');
module.exports = (sequelize, DataTypes) => {
    class Region extends Model {
    }
    Region.init({
        id_region: { type: DataTypes.STRING, primaryKey: true },
        region: { type: DataTypes.STRING, allowNull: false }
    }, {
        sequelize,
        modelName: 'region',
        tableName: 'region',
        timestamps: false
    });
    return Region;
};
