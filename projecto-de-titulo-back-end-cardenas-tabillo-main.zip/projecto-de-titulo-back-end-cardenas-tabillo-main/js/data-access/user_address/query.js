"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const app_1 = __importDefault(require("../country_data/app"));
const queryUserAddress = (conn, models) => {
    return Object.freeze({
        insertAddress,
        updateAddress,
        getAddress,
    });
    function insertAddress(address) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Address = models.user_address;
                const insertedAddress = yield Address.create(address);
                if (!insertedAddress.id_address) {
                    throw new Error('Error while adding address.');
                }
                return { data: insertedAddress, error: null };
            }
            catch (e) {
                console.log(e);
                return { data: null, error: e };
            }
        });
    }
    function updateAddress(address) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Address = models.user_address;
                const { id_user } = address, rest = __rest(address, ["id_user"]);
                const [affected, addressExists] = yield Address.update(Object.assign({}, rest), {
                    where: { id_user: id_user },
                    returning: true,
                    raw: true,
                });
                if (affected !== 1) {
                    throw new Error('Error while updating address.');
                }
                return { data: addressExists[0], error: null };
            }
            catch (e) {
                console.log(e);
                return { data: null, error: e };
            }
        });
    }
    function getAddress(credentials) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Address = models.user_address;
                let address = yield Address.findOne({
                    attributes: [
                        'id_address',
                        'id_region',
                        'id_commune',
                        'address',
                        'lat',
                        'lng',
                        'description',
                    ],
                    where: { id_user: credentials.id_user },
                    raw: true,
                });
                if (!address.id_address) {
                    throw new Error('Error while getting address.');
                }
                const { data: communeData, error: communeError } = yield app_1.default.getCommune(address.id_commune);
                if (communeError) {
                    throw new Error('Error while getting commune.');
                }
                address.commune = communeData;
                const { data: regionData, error: regionError } = yield app_1.default.getRegion(address.id_region);
                if (regionError) {
                    throw new Error('Error while getting region.');
                }
                address.region = regionData;
                delete address.id_region;
                delete address.id_commune;
                return { data: address, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
};
exports.default = queryUserAddress;
