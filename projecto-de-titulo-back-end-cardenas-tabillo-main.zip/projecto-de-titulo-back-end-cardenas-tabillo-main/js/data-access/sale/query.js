"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const app_1 = __importDefault(require("../../entities/mailer/app"));
const mailer_1 = __importDefault(require("../../functions/mailer"));
const uuid = require('uuid');
const querySale = (conn, models) => {
    return Object.freeze({
        createSale,
        uploadFile,
        deleteFile,
        getSalesByUser,
        getSalesBySeller,
        getSaleDetailUser,
        getSaleDetailSeller,
        acceptSale,
        rejectSale,
    });
    function createSale(values) {
        return __awaiter(this, void 0, void 0, function* () {
            const transaction = yield models.sequelize.transaction();
            try {
                const Sale = models.sale;
                const Publication = models.publication;
                const Stock = models.stock;
                const ContentStates = models.content_state;
                const states = yield ContentStates.findAll({
                    raw: true,
                    where: { content_state: ['disponible', 'espera'] },
                });
                const sales = [];
                const publications = [];
                for (let sellerUUID of Object.keys(values.sellers)) {
                    let sellerPublications = yield Publication.findAll({
                        where: {
                            id_fixed: Object.keys(values.sellers[sellerUUID]),
                        },
                        raw: true,
                    });
                    publications.push(...sellerPublications);
                    let total = sellerPublications.reduce((sum, publication) => {
                        sum +=
                            publication.price *
                                values.sellers[sellerUUID][publication.id_fixed];
                        return sum;
                    }, 0);
                    const sale = yield Sale.create({
                        id_sale: uuid.v4(),
                        id_user: values.user.id_user,
                        id_seller: sellerUUID,
                        fixeds: values.sellers[sellerUUID],
                        sale_state: states.filter((s) => s.content_state === 'espera' ? s.id_state : null)[0].id_state,
                        total: total,
                        created_at: new Date(),
                        updated_at: new Date(),
                    }, { raw: true });
                    for (let id_fixed of Object.keys(values.sellers[sellerUUID])) {
                        const publication = publications.filter((pub) => pub.id_fixed === id_fixed ? pub : null)[0];
                        const avaibleStocks = yield Stock.findAll({
                            where: {
                                id_fixed: id_fixed,
                                stock_state: states.filter((s) => s.content_state === 'disponible' ? s : null)[0].id_state,
                            },
                            raw: true,
                        });
                        if (avaibleStocks.length <
                            Number(values.sellers[sellerUUID][id_fixed]) ||
                            publication.current_stock -
                                Number(values.sellers[sellerUUID][id_fixed]) <
                                0) {
                            throw 'No hay suficiente stock para realizar la venta.';
                        }
                        for (let i = 0; i < avaibleStocks.length &&
                            i < Number(values.sellers[sellerUUID][id_fixed]); i++) {
                            yield Stock.update(Object.assign(Object.assign({}, avaibleStocks[i]), { id_sale: sale.id_sale, stock_state: states.filter((s) => s.content_state === 'espera' ? s : null)[0].id_state }), {
                                where: { id_stock: avaibleStocks[i].id_stock },
                                raw: true,
                            });
                        }
                        yield Publication.update(Object.assign(Object.assign({}, publication), { current_stock: publication.current_stock -
                                Number(values.sellers[sellerUUID][id_fixed]) }), { where: { id_fixed: id_fixed } });
                    }
                    sales.push(sale);
                }
                const Sellers = models.seller;
                let mail = app_1.default.optionsTemplate;
                let body = '';
                mail.to = values.user.email;
                mail.subject = 'Compra Subaster';
                for (let sale of sales) {
                    const seller = yield Sellers.findOne({
                        where: { id_seller: sale.id_seller },
                        raw: true,
                    });
                    body +=
                        '<h1>Para las compras en la tienda ' + seller.store_name + '</h1>\n';
                    body += '<h3> El código de la venta es: ' + sale.id_sale + '</h3>';
                    body += '<h2>Debes depositar en la siguiente cuenta:</h2>\n';
                    body += '<h3> Banco: ' + seller.bank_name + '</h3>\n';
                    body += '<h3> Destinatario: ' + seller.bank_account_name + '</h3>\n';
                    body += '<h3> Tipo de cuenta: ' + seller.bank_account_type + '</h3>\n';
                    body += '<h3> Nro de cuenta: ' + seller.bank_account_address + '</h3>\n';
                    body += '<h3> RUT de la cuenta: ' + seller.bank_account_rut + '</h3>\n';
                    body += '<h3> Email de cuenta: ' + seller.bank_account_email + '</h3>\n';
                    body += '<h1>Los articulos comprados son los siguientes</h1>\n';
                    for (let publication of publications) {
                        let url = 'http://localhost:4200/user/publication/' + publication.id_fixed;
                        body = values.sellers[sale.id_seller][publication.id_fixed]
                            ? body +
                                '<h2>' +
                                publication.title +
                                ': <span style="color: green">$CLP ' +
                                values.sellers[sale.id_seller][publication.id_fixed] *
                                    publication.price +
                                ' </span>' +
                                '</h2>' +
                                '<a href=' +
                                url +
                                '>Ver publicación</a>'
                            : body;
                    }
                }
                mail.html = body;
                let status = yield (0, mailer_1.default)(mail);
                transaction.commit();
                return { data: status, error: null };
            }
            catch (e) {
                transaction.rollback();
                return { data: null, error: e };
            }
        });
    }
    function getSalesByUser(id_user) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Sale = models.sale;
                const Stock = models.stock;
                const Publication = models.publication;
                const Files = models.publication_file;
                const Seller = models.seller;
                const ContentState = models.content_state;
                Files.belongsTo(Publication, {
                    foreignKey: 'id_fixed',
                });
                Publication.hasMany(Files, { foreignKey: 'id_fixed' });
                const sales = yield Sale.findAll({
                    where: { id_user: id_user },
                    raw: true,
                    nest: true,
                });
                for (let sale of sales) {
                    sale.sale_state = yield ContentState.findOne({
                        where: { id_state: sale.sale_state },
                        raw: true,
                    });
                    sale.store = yield Seller.findOne({
                        where: { id_seller: sale.id_seller },
                        attributes: { exclude: ['id_seller', 'id_user'] },
                        raw: true,
                    });
                    const ids = yield Stock.findAll({
                        attributes: ['id_fixed'],
                        where: { id_sale: sale.id_sale },
                        raw: true,
                    });
                    let ids_fixed = [];
                    for (let id of ids) {
                        if (!ids_fixed.includes(ids.id_fixed)) {
                            ids_fixed.push(id.id_fixed);
                        }
                    }
                    sale.publications = yield Publication.findAll({
                        where: { id_fixed: ids_fixed },
                        include: [{ model: Files }],
                        raw: true,
                        nest: true,
                    });
                    for (let publication of sale.publications) {
                        let quantity = 0;
                        for (let id of ids) {
                            quantity =
                                id.id_fixed === publication.id_fixed ? quantity + 1 : quantity;
                        }
                        publication.quantity = quantity;
                    }
                }
                return { data: sales, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function getSalesBySeller(id_seller) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Sale = models.sale;
                const Publication = models.publication;
                const Files = models.publication_file;
                const User = models.user;
                const ContentState = models.content_state;
                Files.belongsTo(Publication, {
                    foreignKey: 'id_fixed',
                });
                Publication.hasMany(Files, { foreignKey: 'id_fixed' });
                const sales = yield Sale.findAll({
                    where: { id_seller: id_seller },
                    raw: true,
                    nest: true,
                });
                for (let sale of sales) {
                    sale.sale_state = yield ContentState.findOne({
                        where: { id_state: sale.sale_state },
                        raw: true,
                    });
                    sale.buyer = yield User.findOne({
                        where: { id_user: sale.id_user },
                        attributes: {
                            exclude: ['id_user', 'user_password', 'seller', 'created_at'],
                        },
                        raw: true,
                    });
                }
                return { data: sales, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function getSaleDetailUser(id_sale) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Sale = models.sale;
                const Seller = models.seller;
                const ContentState = models.content_state;
                const Stock = models.stock;
                const Publication = models.publication;
                const Files = models.publication_file;
                const SaleFiles = models.sale_file;
                Files.belongsTo(Publication, {
                    foreignKey: 'id_fixed',
                });
                SaleFiles.belongsTo(Sale, {
                    foreignKey: 'id_sale',
                });
                Publication.hasMany(Files, { foreignKey: 'id_fixed' });
                Sale.hasOne(SaleFiles, {
                    foreignKey: 'id_sale',
                });
                const sale = yield Sale.findOne({
                    where: { id_sale: id_sale },
                    include: [{ model: SaleFiles }],
                    raw: true,
                    nest: true,
                });
                sale.sale_state = yield ContentState.findOne({
                    where: { id_state: sale.sale_state },
                    raw: true,
                });
                sale.store = yield Seller.findOne({
                    where: { id_seller: sale.id_seller },
                    attributes: {
                        exclude: ['id_seller', 'id_user'],
                    },
                    raw: true,
                });
                const ids = yield Stock.findAll({
                    attributes: ['id_fixed'],
                    where: { id_sale: sale.id_sale },
                    raw: true,
                });
                let ids_fixed = [];
                for (let id of ids) {
                    if (!ids_fixed.includes(id.id_fixed)) {
                        ids_fixed.push(id.id_fixed);
                    }
                }
                sale.publications = yield Publication.findAll({
                    where: { id_fixed: ids_fixed },
                    raw: true,
                });
                for (let publication of sale.publications) {
                    let quantity = 0;
                    publication.files = yield Files.findAll({
                        where: { id_fixed: publication.id_fixed },
                    });
                    for (let id of ids) {
                        quantity =
                            id.id_fixed === publication.id_fixed ? quantity + 1 : quantity;
                    }
                    publication.quantity = quantity;
                }
                return { data: sale, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function getSaleDetailSeller(id_sale) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Sale = models.sale;
                const User = models.user;
                const ContentState = models.content_state;
                const Stock = models.stock;
                const Publication = models.publication;
                const Files = models.publication_file;
                const SaleFile = models.sale_file;
                SaleFile.belongsTo(Sale, {
                    foreignKey: 'id_sale',
                });
                Sale.hasOne(SaleFile, {
                    foreignKey: 'id_sale',
                });
                const sale = yield Sale.findOne({
                    where: { id_sale: id_sale },
                    include: [{ model: SaleFile }],
                    raw: true,
                    nest: true,
                });
                sale.sale_state = yield ContentState.findOne({
                    where: { id_state: sale.sale_state },
                    raw: true,
                });
                sale.buyer = yield User.findOne({
                    where: { id_user: sale.id_user },
                    attributes: {
                        exclude: ['id_user, user_password, seller, is_admin, created_at'],
                    },
                    raw: true,
                });
                const ids = yield Stock.findAll({
                    attributes: ['id_fixed'],
                    where: { id_sale: sale.id_sale },
                    raw: true,
                });
                let ids_fixed = [];
                for (let id of ids) {
                    if (!ids_fixed.includes(id.id_fixed)) {
                        ids_fixed.push(id.id_fixed);
                    }
                }
                sale.publications = yield Publication.findAll({
                    where: { id_fixed: ids_fixed },
                    raw: true,
                });
                for (let publication of sale.publications) {
                    let quantity = 0;
                    publication.files = yield Files.findAll({
                        where: { id_fixed: publication.id_fixed },
                    });
                    for (let id of ids) {
                        quantity =
                            id.id_fixed === publication.id_fixed ? quantity + 1 : quantity;
                    }
                    publication.quantity = quantity;
                }
                return { data: sale, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function uploadFile(values) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const SaleFile = models.sale_file;
                const file = yield SaleFile.create(Object.assign(Object.assign({}, values.file), { id_sale: values.id_sale }), {
                    raw: true,
                    nest: true,
                });
                return { data: file, error: null };
            }
            catch (e) {
                console.log(e);
                return { data: null, error: e };
            }
        });
    }
    function deleteFile(id_file) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const SaleFile = models.sale_file;
                const file = yield SaleFile.destroy({
                    where: { id_file: id_file },
                });
                return { data: file, error: null };
            }
            catch (e) {
                console.log(e);
                return { data: null, error: e };
            }
        });
    }
    function acceptSale(id_sale, date, description) {
        return __awaiter(this, void 0, void 0, function* () {
            const transaction = yield models.sequelize.transaction();
            try {
                const Sale = models.sale;
                const Publication = models.publication;
                const Region = models.region;
                const Commune = models.commune;
                const Address = models.publication_address;
                const User = models.user;
                const Seller = models.seller;
                const Stock = models.stock;
                const ContentStates = models.content_state;
                Publication.hasOne(Address, { foreignKey: 'id_fixed' });
                Address.belongsTo(Publication, {
                    foreignKey: 'id_fixed',
                });
                const state = yield ContentStates.findOne({
                    where: { content_state: 'completado' },
                    raw: true,
                    nest: true,
                });
                const sale = yield Sale.findOne({
                    where: { id_sale: id_sale },
                });
                yield Sale.update(Object.assign(Object.assign({}, sale), { sale_state: state.id_state, date_pickup: date, description: description, updated_at: new Date() }), {
                    where: { id_sale: id_sale },
                });
                const stocks = yield Stock.findAll({
                    where: { id_sale: id_sale },
                    raw: true,
                    nest: true,
                });
                for (let stock of stocks) {
                    yield Stock.update(Object.assign(Object.assign({}, stock), { stock_state: state.id_state }), {
                        where: { id_stock: stock.id_stock },
                    });
                }
                const publications = yield Publication.findAll({
                    where: { id_fixed: Object.keys(sale.fixeds) },
                    include: [{ model: Address }],
                    raw: true,
                    nest: true,
                });
                const user = yield User.findOne({
                    where: { id_user: sale.id_user },
                    raw: true,
                    nest: true,
                });
                const seller = yield Seller.findOne({
                    where: { id_seller: sale.id_seller },
                    raw: true,
                    nest: true,
                });
                let mail = app_1.default.optionsTemplate;
                let body = '';
                mail.to = user.email;
                mail.subject = 'Compra Subaster Aceptada';
                body +=
                    '<h2>Tu compra en ' +
                        seller.store_name +
                        ' con N°: ' +
                        sale.id_sale +
                        ' ha sido aceptada</h2>';
                body += '<h2>Podras retirar tus pedidos desde ' + date + '</h2>';
                for (let publication of publications) {
                    const commune = yield Commune.findOne({
                        where: { id_commune: publication.publication_address.id_commune },
                    });
                    const region = yield Region.findOne({
                        where: { id_region: publication.publication_address.id_region },
                    });
                    body += '<h2>Para el producto: ' + publication.title + '</h2>';
                    body +=
                        '<h2>La dirección es: ' +
                            publication.publication_address.address +
                            ',' +
                            commune.commune +
                            ',' +
                            region.region +
                            ',';
                    ',' + '</h2>';
                    body +=
                        '<h2>Tambien puede copiar lo siguiente en el buscador de google maps para encontrar la dirección exacta:' +
                            publication.publication_address.lat +
                            ',' +
                            publication.publication_address.lng +
                            '</h2>';
                }
                body +=
                    '<h2>En caso de ser necesario puedes comunicarte directamente con el vendedor a través de los siguientes canales</h2>';
                body += '<h2>Correo electrónico:' + seller.email + '</h2>';
                body += '<h2>Teléfono:' + seller.phone + '</h2>';
                body += description ? '<h2>Información extra</h2>' : '';
                body += description ? '<p>' + description + '</p>' : '';
                mail.html = body;
                yield (0, mailer_1.default)(mail);
                transaction.commit();
                return { data: sale, error: null };
            }
            catch (e) {
                transaction.rollback();
                console.log(e);
                return { data: null, error: e };
            }
        });
    }
    function rejectSale(id_sale, description) {
        return __awaiter(this, void 0, void 0, function* () {
            const transaction = yield models.sequelize.transaction();
            try {
                const Sale = models.sale;
                const Publication = models.publication;
                const User = models.user;
                const Seller = models.seller;
                const Stock = models.stock;
                const ContentStates = models.content_state;
                const state = yield ContentStates.findAll({
                    where: { content_state: ['disponible', 'rechazado'] },
                    raw: true,
                    nest: true,
                });
                const sale = yield Sale.findOne({
                    where: { id_sale: id_sale },
                    raw: true,
                    nest: true,
                });
                yield Sale.update(Object.assign(Object.assign({}, sale), { sale_state: state.filter((s) => s.content_state === 'rechazado' ? s : null)[0].id_state, description: description, updated_at: new Date() }), {
                    where: { id_sale: id_sale },
                });
                const stocks = yield Stock.findAll({
                    where: { id_sale: id_sale },
                    raw: true,
                    nest: true,
                });
                for (let stock of stocks) {
                    yield Stock.update(Object.assign(Object.assign({}, stock), { stock_state: state.filter((s) => s.content_state === 'disponible' ? s : null)[0].id_state }), {
                        where: { id_stock: stock.id_stock },
                    });
                }
                const publications = yield Publication.findAll({
                    where: { id_fixed: Object.keys(sale.fixeds) },
                    raw: true,
                    nest: true,
                });
                for (let publication of publications) {
                    yield Publication.update(Object.assign(Object.assign({}, publication), { current_stock: publication.current_stock +
                            stocks.filter((s) => s.id_fixed === publication.id_fixed ? s : null).length }), {
                        where: { id_fixed: publication.id_fixed },
                    });
                }
                const user = yield User.findOne({
                    where: { id_user: sale.id_user },
                    raw: true,
                    nest: true,
                });
                const seller = yield Seller.findOne({
                    where: { id_seller: sale.id_seller },
                    raw: true,
                    nest: true,
                });
                let mail = app_1.default.optionsTemplate;
                let body = '';
                mail.to = user.email;
                mail.subject = 'Compra Subaster Rechazada';
                body +=
                    '<h2>Tu compra en ' +
                        seller.store_name +
                        ' con N°: ' +
                        sale.id_sale +
                        ' ha sido rechazada</h2>';
                body += description ? '<h2>Información del rechazo de la venta</h2>' : '';
                body += description ? '<p>' + description + '</p>' : '';
                mail.html = body;
                yield (0, mailer_1.default)(mail);
                transaction.commit();
                return { data: sale, error: null };
            }
            catch (e) {
                transaction.rollback();
                console.log(e);
                return { data: null, error: e };
            }
        });
    }
};
exports.default = querySale;
