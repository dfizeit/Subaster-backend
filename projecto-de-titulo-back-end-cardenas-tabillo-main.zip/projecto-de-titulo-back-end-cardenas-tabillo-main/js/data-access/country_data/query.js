"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const queryCountryData = (conn, models) => {
    return Object.freeze({
        getCommune,
        getRegion,
        getCommunes,
        getRegions,
    });
    function getCommunes() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Commune = models.commune;
                const communes = yield Commune.findAll({ raw: true });
                if ((communes === null || communes === void 0 ? void 0 : communes.length) <= 0) {
                    throw new Error('Error while getting communes.');
                }
                return { data: communes, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function getRegions() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Region = models.region;
                const regions = yield Region.findAll({ raw: true });
                if ((regions === null || regions === void 0 ? void 0 : regions.length) <= 0) {
                    throw new Error('Error while getting regions.');
                }
                return { data: regions, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function getCommune(id) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Commune = models.commune;
                const communes = yield Commune.findOne({
                    where: { id_commune: id },
                    raw: true,
                });
                if ((communes === null || communes === void 0 ? void 0 : communes.length) <= 0) {
                    throw new Error('Error while getting commune.');
                }
                return { data: communes, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function getRegion(id) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Region = models.region;
                const regions = yield Region.findOne({
                    where: { id_region: id },
                    raw: true,
                });
                if ((regions === null || regions === void 0 ? void 0 : regions.length) <= 0) {
                    throw new Error('Error while getting region.');
                }
                return { data: regions, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
};
exports.default = queryCountryData;
