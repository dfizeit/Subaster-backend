"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const app_1 = __importDefault(require("../users/app"));
const app_2 = __importDefault(require("../fixed/app"));
const querySeller = (conn, models) => {
    return Object.freeze({
        join,
        getSeller,
        update,
    });
    function join(values) {
        return __awaiter(this, void 0, void 0, function* () {
            const transaction = yield models.sequelize.transaction();
            try {
                const User = models.user;
                const checkValidUser = yield User.findAll({
                    where: { email: values.email },
                    raw: true,
                });
                if (checkValidUser.filter((user) => user.email === values.email && !(user.id_user === values.id_user)
                    ? user
                    : null).length > 0) {
                    throw new Error('Email ya existente para otro usuario.');
                }
                const Seller = models.seller;
                const checkValidSellerMail = yield Seller.findOne({
                    where: { email: values.email },
                    raw: true,
                });
                if (checkValidSellerMail === null || checkValidSellerMail === void 0 ? void 0 : checkValidSellerMail.id_seller) {
                    throw new Error('Email ya existente para otro vendedor.');
                }
                const updateUser = yield app_1.default.updateUserField('seller', values.id_user, true);
                if (updateUser.data) {
                    const newSeller = yield Seller.create(values);
                    if (newSeller.Errors) {
                        throw new Error('Error while creating seller.');
                    }
                    yield transaction.commit();
                    return { data: newSeller, error: null };
                }
                throw new Error('Error while updating user.');
            }
            catch (e) {
                yield transaction.rollback();
                return { data: null, error: e };
            }
        });
    }
    function update(values) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Seller = models.seller;
                const updatedSeller = yield Seller.update(values, {
                    where: { id_seller: values.id_seller },
                    returning: true,
                    plain: true,
                });
                if (!updatedSeller[1].id_seller) {
                    throw 'Error al actualizar vendedor';
                }
                return { data: updatedSeller[1], error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function getSeller(id_user) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const Seller = models.seller;
                const Files = models.seller_file;
                const seller = yield Seller.findOne({
                    where: { id_user: id_user },
                    raw: true,
                });
                const files = yield Files.findAll({
                    attributes: ['id_file', 'url', 'extensions', 'width', 'height'],
                    where: { id_seller: seller.id_seller },
                    raw: true,
                });
                seller.files = files;
                const { data, error } = yield app_2.default.getSellerPublications(seller.id_seller);
                if (error) {
                    throw error;
                }
                seller.publications = data;
                return { data: seller, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
};
exports.default = querySeller;
