"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const app_1 = require("../../functions/app");
const app_2 = __importDefault(require("../user_address/app"));
const app_3 = __importDefault(require("../user-files/app"));
const app_4 = __importDefault(require("../../entities/mailer/app"));
const mailer_1 = __importDefault(require("../../functions/mailer"));
const queryUser = (conn, models) => {
    return Object.freeze({
        createUser,
        loginUser,
        getUser,
        updateUser,
        updateUserField,
        recoveryPassword,
        updateUserPassword,
    });
    function createUser(user) {
        return __awaiter(this, void 0, void 0, function* () {
            const transaction = yield models.sequelize.transaction();
            try {
                const User = models.user;
                const { address, files } = user, rest = __rest(user, ["address", "files"]);
                const userExists = yield User.findOne({ where: { email: user.email } });
                if (userExists !== null) {
                    throw new Error('User already exists.');
                }
                const createdUser = yield User.create(rest);
                if (!createdUser.id_user) {
                    throw new Error('Error while creating user.');
                }
                address.id_user = createdUser.id_user;
                const addressInserted = yield app_2.default.insertAddress(address);
                if (addressInserted.error) {
                    throw address.error;
                }
                if (user.files) {
                    const filesInserted = yield app_3.default.insertFiles(files, {
                        id_user: createdUser.id_user,
                    });
                    if (filesInserted.error) {
                        throw filesInserted.error;
                    }
                }
                yield transaction.commit();
                return { data: user, error: null };
            }
            catch (e) {
                yield transaction.rollback();
                return { data: null, error: e };
            }
        });
    }
    function updateUser(user) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const User = models.user;
                const updatedUser = yield User.update(user, {
                    where: { email: user.email },
                });
                if (updatedUser.Errors) {
                    throw updatedUser.Errors;
                }
                return { data: updatedUser, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function updateUserField(field, id_user, value) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const User = models.user;
                const change = {};
                change[field] = value;
                const updatedUser = yield User.update(change, {
                    where: { id_user: id_user },
                    raw: true,
                });
                return { data: updatedUser, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function updateUserPassword(credentials) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const User = models.user;
                let userExists = yield User.findOne({
                    where: { id_user: credentials.id_user },
                    raw: true,
                });
                if (userExists === null) {
                    return { errors: "User doesn't exists." };
                }
                if (yield app_1.encrypt.compareString(credentials.current_password, userExists.user_password)) {
                    const updatedUser = yield User.update({ user_password: credentials.new_password }, {
                        where: { id_user: credentials.id_user },
                    });
                    if (updatedUser.errors) {
                        throw new Error('Error while updating password.');
                    }
                    return {
                        data: Object.assign(Object.assign({}, userExists), { user_password: credentials.new_password }),
                        error: null,
                    };
                }
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function loginUser(credentials) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const User = models.user;
                const Files = models.user_file;
                let userExists = yield User.findOne({
                    where: { email: credentials.email },
                    raw: true,
                });
                if (userExists === null) {
                    return { errors: "User doesn't exists." };
                }
                if (yield app_1.encrypt.compareString(credentials.password, userExists.user_password)) {
                    if (userExists.is_admin) {
                        return { data: userExists, error: null };
                    }
                    const { data: address, error: addressError } = yield app_2.default.getAddress({ id_user: userExists.id_user });
                    if (addressError) {
                        throw new Error(addressError);
                    }
                    const files = yield Files.findAll({
                        attributes: ['id_file', 'url', 'extensions', 'width', 'height'],
                        where: { id_user: userExists.id_user },
                        raw: true,
                    });
                    userExists = Object.assign(Object.assign({}, userExists), { address: address, files: files });
                    return { data: userExists, error: null };
                }
                throw new Error('Password is not correct.');
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function getUser(email) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const User = models.user;
                const Files = models.user_file;
                let userExists = yield User.findOne({
                    where: { email: email },
                    raw: true,
                });
                if (userExists === null) {
                    return { data: null, error: "User doesn't exists." };
                }
                let { data: address, error: addressError } = yield app_2.default.getAddress({
                    id_user: userExists.id_user,
                    email: email,
                    user_password: userExists.user_password,
                });
                if (addressError) {
                    throw new Error(addressError);
                }
                const files = yield Files.findAll({
                    attributes: ['id_file', 'url', 'extensions', 'width', 'height'],
                    where: { id_user: userExists.id_user },
                    raw: true,
                });
                userExists = Object.assign(Object.assign({}, userExists), { address: address, files: files });
                return { data: userExists, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
    function recoveryPassword(email, phone) {
        return __awaiter(this, void 0, void 0, function* () {
            const transaction = yield models.sequelize.transaction();
            try {
                const randomstring = require('randomstring');
                const User = models.user;
                const user = yield User.findOne({
                    where: { email: email, phone: phone },
                    raw: true,
                    nest: true,
                });
                if (!user.id_user) {
                    throw 'No existe un usuario con las credenciales proporcionadas';
                }
                let newPassword = randomstring.generate({
                    length: 9,
                    charset: 'alphabetic',
                });
                const user_password = yield app_1.encrypt.encryptString(newPassword);
                const updated = yield User.update(Object.assign(Object.assign({}, user), { user_password: user_password }), {
                    where: { email: email },
                    raw: true,
                    nest: true,
                });
                let mail = app_4.default.optionsTemplate;
                let body = '<div style="text-align: center;">' +
                    '<h1>Subaster</h1>' +
                    '<h4 style="margin-top: 20px">¡Hola! Hemos visto que has perdido tu contraseña</h4>' +
                    '<h4 style="margin-top: 20px">A continuación te adjuntamos tu contraseña, recuerda</h4>' +
                    '<h4 style="margin-top: 20px">no compartir tu contraseña con nadie, si crees que alguien</h4>' +
                    '<h4 style="margin-top: 20px">está usando tu cuenta sin tu consentimiento, contacta a</h4>' +
                    '<h4 style="margin-top: 20px">Subaster. Saludos !</h4>' +
                    '<h5>Contraseña: ' +
                    newPassword +
                    ' </h5>' +
                    '</div>';
                mail.to = email;
                mail.subject = 'Reinicio de Contraseña Subaster';
                mail.html = body;
                yield (0, mailer_1.default)(mail);
                transaction.commit();
                return { data: updated, error: null };
            }
            catch (e) {
                transaction.rollback();
                return { data: null, error: e };
            }
        });
    }
    function deleteUser(idUser) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const User = models.user;
                const deleted = User.destroy({ where: { id_user: idUser } });
                return { data: deleted, error: null };
            }
            catch (e) {
                return { data: null, error: e };
            }
        });
    }
};
exports.default = queryUser;
