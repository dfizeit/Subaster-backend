"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const app_1 = __importDefault(require("../../controllers/baseInfo/app"));
const app_2 = require("../../functions/app");
const route = (router, makeExpressCallback) => {
    router.post('/category', app_2.auth.authVerifyAdmin, makeExpressCallback(app_1.default.insertCategory));
    router.post('/unity', app_2.auth.authVerifyAdmin, makeExpressCallback(app_1.default.insertUnity));
    router.post('/product-state', app_2.auth.authVerifyAdmin, makeExpressCallback(app_1.default.insertProducState));
    router.get('/country', makeExpressCallback(app_1.default.communesAndRegions));
    router.get('/category', makeExpressCallback(app_1.default.categories));
    router.get('/unity', makeExpressCallback(app_1.default.unities));
    router.get('/content-state', makeExpressCallback(app_1.default.contentStates));
    router.get('/product-state', makeExpressCallback(app_1.default.productStates));
    router.get('/publication-properties', makeExpressCallback(app_1.default.publicactionAttributes));
    router.put('/category', app_2.auth.authVerifyAdmin, makeExpressCallback(app_1.default.patchCategory));
    router.put('/unity', app_2.auth.authVerifyAdmin, makeExpressCallback(app_1.default.patchUnity));
    router.put('/product-state', app_2.auth.authVerifyAdmin, makeExpressCallback(app_1.default.patchProductState));
    return router;
};
exports.default = route;
