"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const app_1 = __importDefault(require("../../controllers/users/app"));
const app_2 = require("../../functions/app");
const route = (router, makeExpressCallback) => {
    router.post('/', makeExpressCallback(app_1.default.createUser));
    router.post('/recovery', makeExpressCallback(app_1.default.passworRecovery));
    router.get('/', makeExpressCallback(app_1.default.loginUser));
    router.get('/jwt', app_2.auth.authVerify, makeExpressCallback(app_1.default.getUserByToken));
    router.put('/', app_2.auth.authVerify, makeExpressCallback(app_1.default.updateUser));
    router.put('/password', app_2.auth.authVerify, makeExpressCallback(app_1.default.updateUserPassword));
    router.put('/address', app_2.auth.authVerify, makeExpressCallback(app_1.default.updateUserAddress));
    router.put('/file', app_2.auth.authVerify, makeExpressCallback(app_1.default.updateUserFile));
    router.delete('/file', app_2.auth.authVerify, makeExpressCallback(app_1.default.deleteUserFile));
    return router;
};
exports.default = route;
