"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const app_1 = __importDefault(require("../../controllers/publications/app"));
const app_2 = require("../../functions/app");
const auth_1 = require("../../functions/auth");
const route = (router, makeExpressCallback) => {
    // POST
    router.post('/', app_2.auth.authVerifySeller, makeExpressCallback(app_1.default.postPublication));
    router.post('/repeat', app_2.auth.authVerifySeller, makeExpressCallback(app_1.default.repeatPublication));
    router.post('/file', app_2.auth.authVerifySeller, makeExpressCallback(app_1.default.addFile));
    router.post('/stocks', makeExpressCallback(app_1.default.getPublicationsStocks));
    router.post('/comment', app_2.auth.authVerify, makeExpressCallback(app_1.default.postComment));
    //GET
    router.get('/', makeExpressCallback(app_1.default.getPublication));
    router.get('/can-comment', makeExpressCallback(app_1.default.getCommentPermission));
    router.get('/all', makeExpressCallback(app_1.default.getPublications));
    router.get('/all-admin', auth_1.authVerifyAdmin, makeExpressCallback(app_1.default.getPublicationsForAdmin));
    router.get('/seller', app_2.auth.authVerifySeller, makeExpressCallback(app_1.default.getPublicationsBySeller));
    router.get('/region', makeExpressCallback(app_1.default.getPublicationsByRegion));
    router.get('/home', makeExpressCallback(app_1.default.getHomeInfo));
    //PUT
    router.put('', app_2.auth.authVerifySeller, makeExpressCallback(app_1.default.patchPublication));
    router.put('/address', app_2.auth.authVerifySeller, makeExpressCallback(app_1.default.patchPublicationAddress));
    router.put('/enable', app_2.auth.authVerifySeller, makeExpressCallback(app_1.default.openPublication));
    router.put('/disable', app_2.auth.authVerifySeller, makeExpressCallback(app_1.default.closePublication));
    router.put('/enable-by-admin', app_2.auth.authVerifyAdmin, makeExpressCallback(app_1.default.openPublicationByAdmin));
    router.put('/disable-by-admin', app_2.auth.authVerifyAdmin, makeExpressCallback(app_1.default.closePublicationByAdmin));
    //DELETE
    router.delete('/file', app_2.auth.authVerifySeller, makeExpressCallback(app_1.default.deleteFile));
    return router;
};
exports.default = route;
