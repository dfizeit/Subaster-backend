"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const app_1 = __importDefault(require("../../controllers/sellers/app"));
const app_2 = require("../../functions/app");
const route = (router, makeExpressCallback) => {
    // POST
    router.post('/join', app_2.auth.authVerify, makeExpressCallback(app_1.default.createSeller));
    // PUT
    router.put('', app_2.auth.authVerifySeller, makeExpressCallback(app_1.default.updateSeller));
    //GET
    router.get('', app_2.auth.authVerifySeller, makeExpressCallback(app_1.default.getSeller));
    return router;
};
exports.default = route;
