"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const app_1 = require("../../functions/app");
const app_2 = __importDefault(require("../../controllers/sale/app"));
const route = (router, makeExpressCallback) => {
    // POST
    router.post('', app_1.auth.authVerify, makeExpressCallback(app_2.default.insertSale));
    router.post('/file', app_1.auth.authVerify, makeExpressCallback(app_2.default.addUserSaleFile));
    router.post('/accept', app_1.auth.authVerifySeller, makeExpressCallback(app_2.default.completeSale));
    router.post('/reject', app_1.auth.authVerifySeller, makeExpressCallback(app_2.default.rejectSaleController));
    //GET
    router.get('/by-user', app_1.auth.authVerify, makeExpressCallback(app_2.default.getUserSales));
    router.get('/by-seller', app_1.auth.authVerifySeller, makeExpressCallback(app_2.default.getSellerSales));
    router.get('/detail/user', app_1.auth.authVerify, makeExpressCallback(app_2.default.getSaleDetailUser));
    router.get('/detail/seller', app_1.auth.authVerifySeller, makeExpressCallback(app_2.default.getSaleDetailSeller));
    //DELETE
    router.delete('/file', app_1.auth.authVerify, makeExpressCallback(app_2.default.deleteUserSaleFile));
    return router;
};
exports.default = route;
