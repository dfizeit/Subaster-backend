"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const post_1 = __importDefault(require("./post"));
const app_1 = __importDefault(require("../../entities/publication/app"));
const app_2 = __importDefault(require("../../data-access/fixed/app"));
const app_3 = __importDefault(require("../../data-access/fixed_files/app"));
const app_4 = __importDefault(require("../../data-access/fixed_address/app"));
const get_publications_by_seller_1 = __importDefault(require("./get-publications-by-seller"));
const get_publications_by_region_1 = __importDefault(require("./get-publications-by-region"));
const get_publication_1 = __importDefault(require("./get-publication"));
const delete_file_1 = __importDefault(require("./delete-file"));
const add_file_1 = __importDefault(require("./add_file"));
const update_publication_1 = __importDefault(require("./update-publication"));
const update_publication_address_1 = __importDefault(require("./update-publication-address"));
const get_publications_stock_1 = __importDefault(require("./get-publications-stock"));
const disable_publication_1 = __importDefault(require("./disable-publication"));
const enable_publication_1 = __importDefault(require("./enable-publication"));
const get_all_publications_1 = __importDefault(require("./get-all-publications"));
const insert_comment_1 = __importDefault(require("./insert-comment"));
const app_5 = __importDefault(require("../../data-access/comment/app"));
const verify_comment_permission_1 = __importDefault(require("./verify-comment-permission"));
const home_metrics_1 = __importDefault(require("./home-metrics"));
const re_activate_1 = __importDefault(require("./re-activate"));
const disable_publication_by_admin_1 = __importDefault(require("./disable-publication-by-admin"));
const open_publication_by_admin_1 = __importDefault(require("./open-publication-by-admin"));
const get_all_publications_for_admin_1 = __importDefault(require("./get-all-publications-for-admin"));
const postPublicaction = (0, post_1.default)(app_2.default, app_1.default.createPublication);
const getSellerPublications = (0, get_publications_by_seller_1.default)(app_2.default);
const getRegionPublications = (0, get_publications_by_region_1.default)(app_2.default);
const getPublication = (0, get_publication_1.default)(app_2.default);
const deleteFile = (0, delete_file_1.default)(app_3.default);
const addFile = (0, add_file_1.default)(app_1.default.createFiles, app_3.default);
const updatePublication = (0, update_publication_1.default)(app_1.default.updatePublicationInfo, app_2.default);
const updateAddress = (0, update_publication_address_1.default)(app_1.default.updatePublicationAddress, app_4.default);
const getPublicationsStocks = (0, get_publications_stock_1.default)(app_2.default);
const closePublication = (0, disable_publication_1.default)(app_2.default);
const closePublicationByAdmmin = (0, disable_publication_by_admin_1.default)(app_2.default);
const openPublication = (0, enable_publication_1.default)(app_2.default);
const openPublicationByAdmin = (0, open_publication_by_admin_1.default)(app_2.default);
const getAllPublications = (0, get_all_publications_1.default)(app_2.default);
const postComment = (0, insert_comment_1.default)(app_5.default);
const getCommentPermission = (0, verify_comment_permission_1.default)(app_5.default);
const getHomeInfo = (0, home_metrics_1.default)(app_2.default);
const repeatPublication = (0, re_activate_1.default)(app_2.default);
const getAllPublicationsForAdmin = (0, get_all_publications_for_admin_1.default)(app_2.default);
const publicactionUC = {
    addFile,
    deleteFile,
    getHomeInfo,
    getPublication,
    getAllPublications,
    getAllPublicationsForAdmin,
    updatePublication,
    postPublicaction,
    updateAddress,
    repeatPublication,
    postComment,
    closePublication,
    closePublicationByAdmmin,
    openPublication,
    openPublicationByAdmin,
    getSellerPublications,
    getCommentPermission,
    getRegionPublications,
    getPublicationsStocks,
};
exports.default = publicactionUC;
