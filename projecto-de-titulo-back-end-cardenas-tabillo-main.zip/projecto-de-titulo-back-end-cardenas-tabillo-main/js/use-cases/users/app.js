"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const app_1 = __importDefault(require("../../entities/users/app"));
const app_2 = __importDefault(require("../../data-access/users/app"));
const app_3 = __importDefault(require("../../data-access/user_address/app"));
const app_4 = __importDefault(require("../../data-access/user-files/app"));
const insert_user_1 = __importDefault(require("./insert-user"));
const login_user_1 = __importDefault(require("./login-user"));
const update_user_1 = __importDefault(require("./update-user"));
const update_user_password_1 = __importDefault(require("./update-user-password"));
const update_user_file_1 = __importDefault(require("./update-user-file"));
const update_user_address_1 = __importDefault(require("./update-user-address"));
const delete_file_1 = __importDefault(require("./delete-file"));
const get_user_1 = __importDefault(require("./get-user"));
const passwordRecovery_1 = __importDefault(require("./passwordRecovery"));
const createUser = (0, insert_user_1.default)(app_1.default.makeUsers, app_2.default);
const updateUser = (0, update_user_1.default)(app_1.default.updateUser, app_2.default);
const loginUser = (0, login_user_1.default)(app_1.default.loginUsers, app_2.default);
const updatePassword = (0, update_user_password_1.default)(app_1.default.updateUserPassword, app_2.default);
const updateAddress = (0, update_user_address_1.default)(app_1.default.patchUserAddress, app_3.default);
const updateFile = (0, update_user_file_1.default)(() => { }, app_4.default);
const deleteFile = (0, delete_file_1.default)(app_4.default);
const getUserByToken = (0, get_user_1.default)(app_2.default);
const userPasswordRecovery = (0, passwordRecovery_1.default)(app_2.default);
// user use case
const userUC = {
    createUser,
    updateUser,
    loginUser,
    updatePassword,
    updateAddress,
    updateFile,
    deleteFile,
    getUserByToken,
    userPasswordRecovery,
};
exports.default = userUC;
