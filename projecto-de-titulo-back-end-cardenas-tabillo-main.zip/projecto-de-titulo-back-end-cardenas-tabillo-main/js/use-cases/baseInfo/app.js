"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const get_country_1 = __importDefault(require("./get-country"));
const app_1 = __importDefault(require("../../data-access/country_data/app"));
const app_2 = __importDefault(require("../../data-access/attributes/app"));
const get_categories_1 = __importDefault(require("./get-categories"));
const get_content_states_1 = __importDefault(require("./get-content-states"));
const get_product_states_1 = __importDefault(require("./get-product-states"));
const get_unities_1 = __importDefault(require("./get-unities"));
const get_all_attributes_1 = __importDefault(require("./get-all-attributes"));
const update_category_1 = __importDefault(require("./update-category"));
const update_unity_1 = __importDefault(require("./update-unity"));
const update_product_state_1 = __importDefault(require("./update-product-state"));
const create_category_1 = __importDefault(require("./create-category"));
const create_unity_1 = __importDefault(require("./create-unity"));
const create_product_state_1 = __importDefault(require("./create-product-state"));
const countryInfo = (0, get_country_1.default)(app_1.default);
const attributesCategories = (0, get_categories_1.default)(app_2.default);
const attributesContentStates = (0, get_content_states_1.default)(app_2.default);
const attributesProductStates = (0, get_product_states_1.default)(app_2.default);
const attributesUnities = (0, get_unities_1.default)(app_2.default);
const allAttributes = (0, get_all_attributes_1.default)(app_2.default);
const patchCategory = (0, update_category_1.default)(app_2.default);
const patchUnity = (0, update_unity_1.default)(app_2.default);
const patchProductState = (0, update_product_state_1.default)(app_2.default);
const insertCategory = (0, create_category_1.default)(app_2.default);
const insertUnity = (0, create_unity_1.default)(app_2.default);
const insertProducState = (0, create_product_state_1.default)(app_2.default);
const baseInfoUC = {
    countryInfo,
    attributesCategories,
    attributesContentStates,
    attributesProductStates,
    attributesUnities,
    allAttributes,
    insertCategory,
    insertUnity,
    insertProducState,
    patchCategory,
    patchUnity,
    patchProductState,
};
exports.default = baseInfoUC;
