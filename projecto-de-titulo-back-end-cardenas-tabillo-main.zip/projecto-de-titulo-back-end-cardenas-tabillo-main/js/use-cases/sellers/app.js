"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const join_1 = __importDefault(require("./join"));
const app_1 = __importDefault(require("../../data-access/seller/app"));
const app_2 = __importDefault(require("../../entities/seller/app"));
const get_seller_1 = __importDefault(require("./get-seller"));
const update_seller_1 = __importDefault(require("./update-seller"));
const joinAsSeller = (0, join_1.default)(app_1.default, app_2.default.createSeller);
const getSeller = (0, get_seller_1.default)(app_1.default);
const updateSeller = (0, update_seller_1.default)(app_1.default, app_2.default.updateSeller);
const sellerUC = {
    joinAsSeller,
    getSeller,
    updateSeller,
};
exports.default = sellerUC;
