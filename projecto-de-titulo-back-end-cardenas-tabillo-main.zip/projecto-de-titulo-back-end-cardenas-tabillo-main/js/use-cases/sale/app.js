"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const buy_1 = __importDefault(require("./buy"));
const app_1 = __importDefault(require("../../entities/sale/app"));
const app_2 = __importDefault(require("../../data-access/sale/app"));
const userSales_1 = __importDefault(require("./userSales"));
const saleDetailUser_1 = __importDefault(require("./saleDetailUser"));
const saleDetailSeller_1 = __importDefault(require("./saleDetailSeller"));
const saveUserFile_1 = __importDefault(require("./saveUserFile"));
const destroyUserFile_1 = __importDefault(require("./destroyUserFile"));
const sellerSales_1 = __importDefault(require("./sellerSales"));
const complete_sale_1 = __importDefault(require("./complete-sale"));
const reject_sale_1 = __importDefault(require("./reject-sale"));
const insertSale = (0, buy_1.default)(app_1.default.createSale, app_2.default);
const getSalesByUser = (0, userSales_1.default)(app_2.default);
const getSalesBySeller = (0, sellerSales_1.default)(app_2.default);
const getSaleDetailUser = (0, saleDetailUser_1.default)(app_2.default);
const getSaleDetailSeller = (0, saleDetailSeller_1.default)(app_2.default);
const insertUserSaleFile = (0, saveUserFile_1.default)(app_1.default.creaSaleFile, app_2.default);
const removeUserSaleFile = (0, destroyUserFile_1.default)(app_2.default);
const acceptSale = (0, complete_sale_1.default)(app_2.default);
const cancelSale = (0, reject_sale_1.default)(app_2.default);
const saleUC = {
    insertSale,
    getSalesBySeller,
    acceptSale,
    cancelSale,
    removeUserSaleFile,
    insertUserSaleFile,
    getSaleDetailUser,
    getSaleDetailSeller,
    getSalesByUser,
};
exports.default = saleUC;
